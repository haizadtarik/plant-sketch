import mqtt from 'mqtt';
import { readFileSync } from 'node:fs';
import { initialState, step, telemetry } from './simulation.mjs';
const config=JSON.parse(readFileSync(new URL('./simulation-config.json',import.meta.url),'utf8'));
const client=mqtt.connect(process.env.MQTT_URL||'mqtt://broker:1883',{reconnectPeriod:1000});
let state=initialState(config.initial.source,config.initial.destination),command={pump:false,valve:50,fault:false};
client.on('connect',()=>client.subscribe(config.tags.filter(t=>t.direction==='command').map(t=>t.topic)));
// FUXA retains command topics. Ignore subscription replays so restart does not replay an old Start.
client.on('message',(topic,payload,packet)=>{if(packet.retain)return;const tag=config.tags.find(t=>t.topic===topic&&t.direction==='command');const value=Number(payload.toString());if(!tag||!Number.isFinite(value))return;if(tag.key==='pumpCommand'&&(value===0||value===1))command.pump=value===1;if(tag.key==='valveCommand')command.valve=Math.min(100,Math.max(0,value));});
client.on('error',e=>console.error('MQTT:',e.message));
// Fixed 250 ms logical step, shared exactly with browser. No random behavior.
setInterval(()=>{state=step(state,command,.25);const values=telemetry(state,command);for(const tag of config.tags.filter(t=>t.direction==='telemetry'))client.publish(tag.topic,String(values[tag.key]),{retain:true});},250);
process.on('SIGTERM',()=>client.end());
