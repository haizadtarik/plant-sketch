# P&ID Studio runtime — demonstration only

Requires Docker Desktop / Docker Engine with Compose. Run from this directory:

    docker compose up --build -d

Open http://localhost:1881. Enter the FUXA editor, use the header's Open project control to select project.json, then Save. The pinned source header calls setProject(project,true); no undocumented autoload endpoint is used. Use the viewer to operate Start pump, Stop pump and valve preset buttons. Use the editor to edit native SVG shapes and tag properties.

Device Demo MQTT must be enabled, address mqtt://broker:1883. Connection should become green. Levels, flow, pump feedback/fault and valve feedback arrive via raw scalar MQTT topics. Commands use separate pnid/command/* topics, telemetry uses pnid/telemetry/*. Simulator defaults: 800 / 200 L, 1000 L capacity, 20 L/s maximum, linear valve opening. Empty source/full receiving tank stops transfer. These are demo assumptions, not a digital twin or inferred process control.

FUXA pinned to v1.2.9, source commit 19c2471833e410eea235b81857ddcfde7b3851a0. Project v1.01, native svg-ext-shapes / svg-ext-value gauge structures, raw MQTT reads/writes and shape click events inspected from that source. Image built from pinned npm package rather than an unverified Docker tag.

Verified on 6 October 2026 in FUXA 1.2.9, Node 22.15.0, Docker Linux arm64: UI import, independent tank/display editing, save/export/reload, live MQTT values, pump start/stop, valve 0/50/100%, transfer limits and simulator restart. Native editor exports, screenshots and MQTT observations are retained in docs/evidence/fuxa-1.2.9 in the source repository. Verification covers this supported demo template and pinned version, not real plant control or other FUXA versions.

Broker is internal to the Compose network; FUXA binds only to localhost. No real PLCs. Restart simulator to reset state. Retained command replays are ignored, so restart restores pump stopped and valve 50%; click controls again to issue fresh commands. Stop with docker compose down. Remove volumes only if you deliberately want to delete FUXA changes.
